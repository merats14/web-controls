﻿using IEMS.Identity.Connect.OAuth2.Configurations._Common;
using IEMS.Identity.Connect.OAuth2.Configurations._Models;
using IEMS.Identity.Connect.OAuth2.Configurations._OauthRequest;
using IEMS.Identity.Connect.OAuth2.Configurations._OauthResponse;
using IEMS.IdentityServer.Model.Helper;
using IEMS_IDP.OAuth2.Configurations._Services;
using IEMS_IDP.Utility;
using Microsoft.Extensions.Options;
using Microsoft.IdentityModel.Tokens;
using System.IdentityModel.Tokens.Jwt;
using System.Security.Claims;
using System.Text;

namespace IEMS.Identity.Connect.OAuth2.Configurations._Services
{
    /// <summary>
    /// 
    /// </summary>
    public class AuthorizeResultService : IAuthorizeResultService
    {
        private readonly IConfiguration _config;
        private readonly string tokenSecretKey = string.Empty;
        private readonly string tokenIssuer = string.Empty;
        private readonly double tokenExpiryMinute = 180;
        private readonly ICodeStoreService _codeStoreService;
        private readonly IClientService _clientService;

        /// <summary>
        /// 
        /// </summary>
        /// <param name="clientService"></param> 
        /// <param name="config"></param>
        /// <param name="codeStoreService"></param>
        public AuthorizeResultService(IClientService clientService,
            IConfiguration config, ICodeStoreService codeStoreService)
        {
            _config = config;
            _codeStoreService = codeStoreService;
            tokenSecretKey = _config["tokenSettings:key"];
            tokenIssuer = _config["tokenSettings:issuer"];
            tokenExpiryMinute = Convert.ToDouble(_config["tokenSettings:expiryTime"]);
            _clientService = clientService;
        }


        /// <summary>
        ///  Verify that a scope parameter is present and contains the openid scope value.
        ///  (If no openid scope value is present,
        ///  the request may still be a valid OAuth 2.0 request, but is not an OpenID Connect request.)
        ///  
        /// check the return url is match the one that in the client store
        /// check the scope in the client store with the
        /// one that is coming from the request MUST be matched at least one
        /// </summary>
        /// <param name="httpContextAccessor"></param>
        /// <param name="authorizationRequest"></param>
        /// <returns></returns>
        public AuthorizeResponse AuthorizeRequest(IHttpContextAccessor httpContextAccessor, AuthorizationRequest authorizationRequest)
        {
            AuthorizeResponse response = new AuthorizeResponse();

            if (httpContextAccessor == null)
            {
                response.Error = ErrorTypeEnum.ServerError.GetEnumDescription();
                return response;
            }

            var client = VerifyClientById(authorizationRequest.client_id);
            if (!client.IsSuccess)
            {
                response.Error = client.ErrorDescription;
                return response;
            }

            if (string.IsNullOrEmpty(authorizationRequest.response_type) || authorizationRequest.response_type != "code")
            {
                response.Error = ErrorTypeEnum.InvalidRequest.GetEnumDescription();
                response.ErrorDescription = "response_type is required or is not valid";
                return response;
            }

            if (!authorizationRequest.redirect_uri.IsRedirectUriStartWithHttps() && !httpContextAccessor.HttpContext.Request.IsHttps)
            {
                response.Error = ErrorTypeEnum.InvalidRequest.GetEnumDescription();
                response.ErrorDescription = "redirect_url is not secure, MUST be TLS";
                return response;
            }

            var scopes = authorizationRequest.scope.Split(' ');

            var clientScopes = from m in client.Client.AllowedScopes
                               where scopes.Contains(m)
                               select m;

            if (!clientScopes.Any())
            {
                response.Error = ErrorTypeEnum.InValidScope.GetEnumDescription();
                response.ErrorDescription = "scopes are invalids";
                return response;
            }

            string nonce = httpContextAccessor.HttpContext.Request.Query["nonce"].ToString();
            string code = _codeStoreService.GenerateAuthorizationCode(authorizationRequest.client_id, clientScopes.ToList());
            if (code == null)
            {
                response.Error = ErrorTypeEnum.TemporarilyUnAvailable.GetEnumDescription();
                return response;
            }

            response.RedirectUri = client.Client.RedirectUri + "?response_type=code" + "&state=" + authorizationRequest.state;
            response.Code = code;
            response.State = authorizationRequest.state;
            response.RequestedScopes = clientScopes.ToList();
            response.Nonce = nonce;

            return response;
        }




        private CheckClientResult VerifyClientById(string clientId, bool checkWithSecret = false, string clientSecret = null)
        {
            CheckClientResult result = new CheckClientResult() { IsSuccess = false };

            if (!string.IsNullOrWhiteSpace(clientId))
            {
                var client = _clientService.AllClients().Where(x => x.ClientId.Equals(clientId, StringComparison.OrdinalIgnoreCase)).FirstOrDefault();

                if (client != null)
                {
                    if (checkWithSecret && !string.IsNullOrEmpty(clientSecret))
                    {
                        bool hasSameSecretId = client.ClientSecret.Equals(clientSecret, StringComparison.InvariantCulture);
                        if (!hasSameSecretId)
                        {
                            result.Error = ErrorTypeEnum.InvalidClient.GetEnumDescription();
                            return result;
                        }
                    }
                    result.IsSuccess = true;
                    result.Client = client;
                    return result;
                }
            }

            result.ErrorDescription = ErrorTypeEnum.AccessDenied.GetEnumDescription();
            return result;
        }


        /// <summary>
        /// Generate Token
        /// </summary>
        /// <param name="httpContextAccessor"></param>
        /// <returns></returns>
        public TokenResponse GenerateToken(IHttpContextAccessor httpContextAccessor)
        {
            DateTime utcTs = DateTimeExtension.DateTimeInIndianStdTime;

            TokenRequest request = new TokenRequest();
            request.CodeVerifier = httpContextAccessor.HttpContext.Request.Form["code_verifier"];
            request.ClientId = httpContextAccessor.HttpContext.Request.Form["client_id"];
            request.ClientSecret = httpContextAccessor.HttpContext.Request.Form["client_secret"];
            request.Code = httpContextAccessor.HttpContext.Request.Form["code"];
            request.GrantType = httpContextAccessor.HttpContext.Request.Form["grant_type"];
            request.RedirectUri = httpContextAccessor.HttpContext.Request.Form["redirect_uri"];

            var checkClientResult = this.VerifyClientById(request.ClientId, true, request.ClientSecret);
            if (!checkClientResult.IsSuccess)
            {
                return new TokenResponse { Error = checkClientResult.Error, ErrorDescription = checkClientResult.ErrorDescription };
            }

            // check code from the Concurrent Dictionary
            var clientCodeChecker = _codeStoreService.GetClientDataByCode(request.Code);
            if (clientCodeChecker == null)
                return new TokenResponse { Error = ErrorTypeEnum.InvalidGrant.GetEnumDescription() };


            // check if the current client who is one made this authentication request

            if (request.ClientId != clientCodeChecker.ClientId)
                return new TokenResponse { Error = ErrorTypeEnum.InvalidGrant.GetEnumDescription() };

            // TODO: 
            // also I have to check the redirect uri 


            // Now here I will Issue the Id_token

            var claims = clientCodeChecker.Subject.Claims.ToList();

            JwtSecurityToken id_token = null;
            if (clientCodeChecker.IsOpenId)
            {
                int iat = (int)utcTs.Subtract(new DateTime(1970, 1, 1)).TotalSeconds;
                var key = new SymmetricSecurityKey(Encoding.UTF8.GetBytes(tokenSecretKey));
                var credentials = new SigningCredentials(key, SecurityAlgorithms.HmacSha256);
                claims.Add(new Claim("iat", iat.ToString(), ClaimValueTypes.Integer));
                claims.Add(new Claim("nonce", clientCodeChecker.Nonce));

                id_token = new JwtSecurityToken(tokenIssuer, request.ClientId, claims, signingCredentials: credentials,
                    expires: utcTs.AddMinutes(tokenExpiryMinute));
            }
            claims.Add(new("auth_time", utcTs.ToString()));
            claims.Add(new("iss", tokenIssuer));
            // Here I have to generate access token 
            var key_at = new SymmetricSecurityKey(Encoding.UTF8.GetBytes(tokenSecretKey));
            var credentials_at = new SigningCredentials(key_at, SecurityAlgorithms.HmacSha256);

            var access_token = new JwtSecurityToken(tokenIssuer, request.ClientId, claims, signingCredentials: credentials_at,
                expires: utcTs.AddMinutes(tokenExpiryMinute));

            // here remove the code from the Concurrent Dictionary
            _codeStoreService.RemoveClientDataByCode(request.Code);

            return new TokenResponse
            {
                access_token = new JwtSecurityTokenHandler().WriteToken(access_token),
                id_token = id_token != null ? new JwtSecurityTokenHandler().WriteToken(id_token) : null,
                code = request.Code
            };
        }
    }
}
