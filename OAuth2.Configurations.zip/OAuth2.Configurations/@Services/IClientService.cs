﻿using IEMS.Identity.Connect.OAuth2.Configurations._Models;

namespace IEMS_IDP.OAuth2.Configurations._Services
{
    /// <summary>
    /// Client Service
    /// </summary>
    public interface IClientService
    {
        /// <summary>
        /// get all clients which are configured into the system.
        /// </summary>
        /// <returns></returns>
        IEnumerable<Client> AllClients();
    }
}
