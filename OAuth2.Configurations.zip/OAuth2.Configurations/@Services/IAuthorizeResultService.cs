﻿using IEMS.Identity.Connect.OAuth2.Configurations._OauthRequest;
using IEMS.Identity.Connect.OAuth2.Configurations._OauthResponse;

namespace IEMS.Identity.Connect.OAuth2.Configurations._Services
{
    public interface IAuthorizeResultService
    {
        AuthorizeResponse AuthorizeRequest(IHttpContextAccessor httpContextAccessor, AuthorizationRequest authorizationRequest);
        TokenResponse GenerateToken(IHttpContextAccessor httpContextAccessor);
    }
}
