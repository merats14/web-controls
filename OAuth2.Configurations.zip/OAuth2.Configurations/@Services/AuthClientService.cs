﻿using IEMS.Identity.Connect.OAuth2.Configurations._Models;
using IEMS.IdentityServer.Model.Helper;
using Microsoft.Extensions.Options;

namespace IEMS_IDP.OAuth2.Configurations._Services
{
    /// <summary>
    /// Auth Client Service
    /// </summary>
    public class AuthClientService : IClientService
    {
        private readonly AppConfiguration _appSettings;
        /// <summary>
        /// Auth Client Service
        /// </summary>
        public AuthClientService(IOptions<AppConfiguration> appSettings)
        {
            _appSettings = appSettings.Value;
        }


        /// <summary>
        /// read all clients from db
        /// </summary>
        /// <returns></returns> 
        public IEnumerable<Client> AllClients()
        {
            var allClients = _appSettings.OpenIdClients.Where(c => c.IsActive).Select(c => new Client()
            {
                ClientId = c.ClientId,
                ClientName = c.ClientName,
                ClientSecret = c.ClientSecret,
                AllowedScopes = c.Scopes.Split(","),
                ClientUri = c.ClientUri,
                GrantType = GrantTypes.Code,
                IsActive = c.IsActive,
                RedirectUri = c.RedirectUri
            });
            return allClients;
        }
    }
}
