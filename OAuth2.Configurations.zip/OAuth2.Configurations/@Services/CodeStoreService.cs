﻿using IEMS.Identity.Connect.OAuth2.Configurations._Models;
using IEMS.IdentityServer.Model.Helper;
using IEMS_IDP.Entity;
using IEMS_IDP.OAuth2.Configurations._Services;
using Microsoft.AspNetCore.Authentication.Cookies;
using Microsoft.Extensions.Options;
using System.Collections.Concurrent;
using System.IdentityModel.Tokens.Jwt;
using System.Security.Claims;

namespace IEMS.Identity.Connect.OAuth2.Configurations._Services
{
    /// <summary>
    /// Code Store Service
    /// </summary>
    public class CodeStoreService : ICodeStoreService
    {
        private readonly ConcurrentDictionary<string, AuthorizationCode> _codeIssued = new ConcurrentDictionary<string, AuthorizationCode>();

        private readonly IClientService _clientService;
        /// <summary>
        /// 
        /// </summary>
        /// <param name="appSettings"></param>
        public CodeStoreService(IOptions<AppConfiguration> appSettings, IClientService clientService)
        {
            _clientService = clientService;
        }

        /// <summary>
        /// Here I generate the code for authorization, and I will store it 
        /// in the Concurrent Dictionary
        /// </summary>
        /// <param name="clientId"></param>
        /// <param name="requestedScope"></param>
        /// <returns></returns>
        public string GenerateAuthorizationCode(string clientId, IList<string> requestedScope)
        {
            var client = _clientService.AllClients().Where(x => x.ClientId == clientId).FirstOrDefault();
            if (client != null)
            {
                var code = Guid.NewGuid().ToString();
                var authCode = new AuthorizationCode
                {
                    ClientId = clientId,
                    RedirectUri = client.RedirectUri,
                    RequestedScopes = requestedScope,
                };
                // then store the code is the Concurrent Dictionary
                _codeIssued[code] = authCode;
                return code;
            }
            return null;
        }


        /// <summary>
        /// Get Client Data By Code
        /// </summary>
        /// <param name="key"></param>
        /// <returns></returns>
        public AuthorizationCode GetClientDataByCode(string key)
        {
            AuthorizationCode authorizationCode;
            if (_codeIssued.TryGetValue(key, out authorizationCode))
            {
                return authorizationCode;
            }
            return null;
        }


        /// <summary>
        /// Remove Client DataBy Code
        /// </summary>
        /// <param name="key"></param>
        /// <returns></returns>
        public AuthorizationCode RemoveClientDataByCode(string key)
        {
            AuthorizationCode authorizationCode;
            _codeIssued.TryRemove(key, out authorizationCode);
            return null;
        }


        /// <summary>
        /// check the requested scopes with the one that are stored in the Client Store 
        /// Before updated the Concurrent Dictionary I have to Process User Sign In,
        /// and check the user credential first
        /// But here I merge this process here inside update Concurrent Dictionary method
        /// </summary>
        /// <param name="key"></param>
        /// <param name="requestedScopes"></param>
        /// <param name="idpUser"></param>
        /// <param name="clientId"></param>
        /// <param name="nonce"></param>
        /// <returns></returns>
        public AuthorizationCode UpdatedClientDataByCode(string key,
            IList<string> requestedScopes, IdpUserDTO idpUser, string clientId, string nonce = null)
        {
            var oldValue = GetClientDataByCode(key);
            if (oldValue != null)
            {
                // 
                var client = _clientService.AllClients().Where(x => x.ClientId == oldValue.ClientId).FirstOrDefault();
                if (client != null)
                {
                    var clientScope = (from m in client.AllowedScopes
                                       where requestedScopes.Contains(m)
                                       select m).ToList();
                    if (!clientScope.Any())
                        return null;

                    AuthorizationCode newValue = new()
                    {
                        ClientId = oldValue.ClientId,
                        CreationTime = oldValue.CreationTime,
                        IsOpenId = requestedScopes.Contains("openId") || requestedScopes.Contains("profile"),
                        RedirectUri = oldValue.RedirectUri,
                        RequestedScopes = requestedScopes,
                        Nonce = nonce
                    };
                    string[] _fullNameCollection = new[] { idpUser.FirstName ?? "", idpUser.MiddleName ?? "", idpUser.LastName ?? "" };
                    string fullName = string.Join(" ", _fullNameCollection);
                    List<Claim> claims = new()
                    {
                        new(JwtRegisteredClaimNames.Jti, Guid.NewGuid().ToString()),
                        new(JwtRegisteredClaimNames.Name, fullName),
                        new(JwtRegisteredClaimNames.NameId, idpUser.UserId.ToString()),
                        new(JwtRegisteredClaimNames.GivenName, idpUser.FirstName ?? ""),
                        new(JwtRegisteredClaimNames.Email,idpUser.EmailId),
                        new(JwtRegisteredClaimNames.FamilyName,idpUser.LastName ?? ""),
                        new("sub", idpUser.UserId.ToString()),
                        new("amr", "iems-sso"),// authentication method reference 
                        new("user_id", idpUser.UserId.ToString()),
                        new("first_name", idpUser.FirstName ?? ""),
                        new("middle_name", idpUser.MiddleName ?? ""),
                        new("last_name", idpUser.LastName ?? ""),
                        new("client_id", clientId.ToString()),
                        new("mobile_number", (idpUser.MobileNumber ?? "")),
                        new("user_type_code", idpUser.UserTypeInfo.Code),
                        new("user_type_name", idpUser.UserTypeInfo.DisplayName),
                        new("nickname",idpUser.FirstName ?? ""),
                        new("zoneinfo", "Time zone in India (GMT+5:30)"),
                        new("email_verified", "true"),
                        new("locale", "en-US")
                    };
                    var claimIdentity = new ClaimsIdentity(claims, CookieAuthenticationDefaults.AuthenticationScheme);
                    newValue.Subject = new ClaimsPrincipal(claimIdentity);
                    var result = _codeIssued.TryUpdate(key, newValue, oldValue);
                    if (result)
                        return newValue;
                    return null;
                }
            }
            return null;
        }
    }
}
