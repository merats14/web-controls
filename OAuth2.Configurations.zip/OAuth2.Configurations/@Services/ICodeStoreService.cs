﻿using IEMS.Identity.Connect.OAuth2.Configurations._Models;
using IEMS_IDP.Entity;

namespace IEMS.Identity.Connect.OAuth2.Configurations._Services
{
    public interface ICodeStoreService
    {
        string GenerateAuthorizationCode(string clientId, IList<string> requestedScope);
        AuthorizationCode GetClientDataByCode(string key);
        AuthorizationCode RemoveClientDataByCode(string key);
        AuthorizationCode UpdatedClientDataByCode(string key, IList<string> requestedScopes, IdpUserDTO idpUser, string clientId, string nonce = null);
    }
}