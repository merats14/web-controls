﻿using System.ComponentModel;

namespace IEMS.Identity.Connect.OAuth2.Configurations._Models
{
    public enum TokenTypeEnum : byte
    {
        [Description("Bearer")]
        Bearer
    }
}
