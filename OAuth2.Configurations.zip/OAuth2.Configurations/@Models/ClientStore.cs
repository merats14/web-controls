﻿namespace IEMS.Identity.Connect.OAuth2.Configurations._Models
{
    public class ClientStores
    {
        public IEnumerable<Client> Clients = new[]
        {
            new Client
            {
                ClientName = "platform .Net 6",
                ClientId = "one-portal-dashboard",
                ClientSecret = "45D6CA70-5604-43F2-9F90-73CA1A3A7673",
                AllowedScopes = new[]{ "openid", "profile"},
                GrantType = GrantTypes.Code,
                IsActive = true,
                ClientUri = "https://localhost:7122",
                RedirectUri = "https://localhost:7122/signin-oidc"
            }
        };
    }
}
