﻿using Azure.Core;
using IEMS.Core.Academics.Database.DatabaseEntities;
using IEMS.Core.ApplicationCommonConfigurations.Interfaces;
using IEMS_IDP.Entity;
using IEMS_IDP.Entity.Account;
using IEMS_IDP.Entity.CustomException;
using IEMS_IDP.Services.Interface;
using IEMS_IDP.Services.Interface.LMSAuth;
using IEMS_IDP.Utility;
using Microsoft.AspNetCore.Mvc;
using System.Net;
using static Microsoft.ApplicationInsights.MetricDimensionNames.TelemetryContext;

namespace IEMS_IDP.Controllers
{
    /// <summary>
    /// account controller is responsible to handle user login and authorizations
    /// </summary>
    [Route("api/[controller]")]
    [ApiController]
    public class AccountController : ControllerBase
    {
        private readonly IApplicationCommonConfigurations _commonConfigurations;
        private readonly ILogger<AccountController> _logger;
        private readonly IConfiguration _config;
        private readonly IAuthService _authServices;
        private readonly ISessionInfoServices _sessionInfoServices;
        private readonly IOpenAMService _openAMService;
        private readonly ICookieService _cookieService;
        private readonly IUserInfoData _userInfo;
        private readonly ILMSAuthService _lmsAuthService;
        private readonly IWebHostEnvironment _environment;

        private readonly string[] StudentPortals = new[] { "STUDENT PORTAL", "EXAM-PORTAL-STUDENT" };
        private readonly string OnePortalName = "SLCM PORTAL";
        private readonly string LMSPortalCode = "LMS";
        private readonly string[] StaffPortals = new[] { "SLCM PORTAL", "STAFF PORTAL", "EXAM-PORTAL-ADMIN", "LMS", "FINANCE-PORTAL-ADMIN" };

        /// <summary>
        /// constructor for account controller
        /// </summary>
        /// <param name="logger"></param>
        /// <param name="config"></param>
        /// <param name="authServices"></param>
        /// <param name="sessionInfoServices"></param>
        /// <param name="openAMService"></param>
        /// <param name="cookieService"></param>
        /// <param name="userInfo"></param>
        /// <param name="commonConfigurations"></param>
        /// <param name="lmsAuthService"></param>
        /// <param name="environment"></param>
        public AccountController(ILogger<AccountController> logger, IConfiguration config,
            IAuthService authServices,
            ISessionInfoServices sessionInfoServices,
            IOpenAMService openAMService,
            ICookieService cookieService,
            IUserInfoData userInfo,
            IApplicationCommonConfigurations commonConfigurations,
            ILMSAuthService lmsAuthService, IWebHostEnvironment environment)
        {
            _logger = logger;
            _config = config;
            _authServices = authServices;
            _sessionInfoServices = sessionInfoServices;
            _openAMService = openAMService;
            _cookieService = cookieService;
            _userInfo = userInfo;
            _commonConfigurations = commonConfigurations;
            _lmsAuthService = lmsAuthService;
            _environment = environment;
        }

        #region ADFS SETUP

        ///// <summary>
        ///// this method will get execute from UI to get authenticated from ADFS.
        ///// user will redirect to ADFS login page.
        ///// </summary>
        ///// <returns></returns>
        //[HttpGet]
        //[Route("/adfs/oauth2/authorize")]
        //public IActionResult Authorize()
        //{
        //    string innuserAddres = _config.GetValue<string>("ADFSSSO:ISSUERADDRESS");
        //    string wtrealm = _config.GetValue<string>("ADFSSSO:WTREALM");
        //    var signInMessage = new WsFederationMessage();
        //    signInMessage.IssuerAddress = innuserAddres;
        //    signInMessage.Wtrealm = wtrealm;
        //    var redirectUri = signInMessage.CreateSignInUrl();
        //    return RedirectPermanent(redirectUri);
        //}

        ///// <summary>
        ///// this method will get called from ADFS after successfull login in the ADFS
        ///// </summary>
        ///// <returns></returns>
        //[HttpPost]
        //[Route("/adfs/oauth2/authorize")]
        //[Route("/")]
        //public async Task<IActionResult> AdfsPostRedirect()
        //{
        //    var onePortalConfig = _clientDetails.FirstOrDefault(c => c.ClientName == OnePortalName);
        //    try
        //    {
        //        string innuserAddres = _config.GetValue<string>("ADFSSSO:ISSUERADDRESS");
        //        string wtrealm = _config.GetValue<string>("ADFSSSO:WTREALM");
        //        var response = await this.Request.ReadFormAsync();
        //        var Item = new List<KeyValuePair<string, string[]>>();
        //        foreach (var oCollection in response)
        //        {
        //            Item.Add(new KeyValuePair<string, string[]>(oCollection.Key, oCollection.Value));
        //        }
        //        WsFederationMessage wsFederationMessage = new WsFederationMessage(Item);
        //        string token = wsFederationMessage.GetToken();
        //        SecurityToken validatedToken;
        //        var tokenHandler = new SamlSecurityTokenHandler()
        //        {
        //            MaximumTokenSizeInBytes = Int32.MaxValue
        //        };
        //        var tokenValidationParameters = new TokenValidationParameters()
        //        {
        //            AudienceValidator = (audiences, token, parameters) =>
        //            {
        //                return true;
        //            },
        //            IssuerValidator = (issuer, token, parameters) =>
        //            {
        //                return issuer;
        //            },
        //            IssuerSigningKeyValidator = (key, token, parameters) =>
        //            {
        //                if (key is X509SecurityKey)
        //                {
        //                    X509SecurityKey x509Key = (X509SecurityKey)key;
        //                    return true;
        //                }
        //                else
        //                {
        //                    return false;
        //                }
        //            },
        //            IssuerSigningKeyResolver = (token, securityToken, kid, parameters) =>
        //            {
        //                var samlToken = (SamlSecurityToken)securityToken;
        //                var signature = samlToken.Assertion.Signature;
        //                var certificate = signature.KeyInfo.X509Data.FirstOrDefault().Certificates.FirstOrDefault();
        //                var x509Certificate2 = new X509Certificate2(System.Convert.FromBase64String(certificate));
        //                return new List<X509SecurityKey>()
        //                    {
        //                    new X509SecurityKey(x509Certificate2)
        //                    };
        //            }
        //        };
        //        var validatedPrincipal = tokenHandler.ValidateToken(token, tokenValidationParameters, out validatedToken);
        //        if (validatedPrincipal != null)
        //        {
        //            string emailId = validatedPrincipal.Claims.First(c => c.Type == ClaimTypes.Email).Value;
        //            var userInfo = await _userInfo.GetUserDetailsByEmail(emailId, 0);
        //            if (userInfo != null)
        //            {
        //                var doc = XDocument.Parse(token);
        //                var jobject = JsonConvert.SerializeXNode(doc, Formatting.Indented, omitRootObject: true);
        //                JObject json = JObject.Parse(jobject);
        //                ADFSTokenResponseModel adfsTokenResponse = new()
        //                {
        //                    SignatureValue = json["ds:Signature"]["ds:SignatureValue"].ToString(),
        //                    AttributeName = json["saml:AttributeStatement"]["saml:Attribute"]["@AttributeName"].ToString(),
        //                    ConfirmationMethod = json["saml:AttributeStatement"]["saml:Subject"]["saml:SubjectConfirmation"]["saml:ConfirmationMethod"].ToString()
        //                };
        //                string userTypeCode = userInfo.UserTypeInfo.Code.ToLower();
        //                var clientInfo = GetClientInfoByUserTypeCode(userTypeCode);
        //                string idp_session_info = _cookieService.GetIdpCookie(Constants.IDP_SESSION_INFO);
        //                var client_id = clientInfo.IdpClientId;
        //                var authCode_redirect_uri = clientInfo.RedirectAuthCodeUri;
        //                return await HandleIdpLoginAsync(new OpenAMUserInfo
        //                {
        //                    Email = userInfo.EmailId
        //                }, new OpenAMToken
        //                {
        //                    AccessToken = adfsTokenResponse.SignatureValue,
        //                    Scope = adfsTokenResponse.AttributeName,
        //                    TokenType = adfsTokenResponse.ConfirmationMethod,
        //                    RefreshToken = string.Empty,
        //                    IdToken = string.Empty,
        //                    ExpiresIn = 0
        //                }, clientInfo);
        //            }
        //        }
        //    }
        //    catch (Exception error)
        //    {
        //        _logger.LogError("After Signin Error :ADFS - " + error.Message, error);
        //    }
        //    return RedirectPermanent(onePortalConfig.ErrorPageUrl);
        //}

        ///// <summary>
        ///// this method will logout from the adfs
        ///// </summary>
        ///// <returns></returns>
        //private IActionResult AdfsLogoutRedirect()
        //{
        //    string innuserAddres = _config.GetValue<string>("ADFSSSO:ISSUERADDRESS");
        //    string wtrealm = _config.GetValue<string>("ADFSSSO:WTREALM");
        //    var signInMessage = new WsFederationMessage();
        //    signInMessage.IssuerAddress = innuserAddres;
        //    signInMessage.Wtrealm = wtrealm + "?code=" + Guid.NewGuid().ToString();
        //    var redirectUri = signInMessage.CreateSignOutUrl();
        //    return RedirectPermanent(redirectUri);
        //}

        ///// <summary>
        ///// this method will get called from ADFS after successfull logout
        ///// </summary>
        ///// <returns></returns>
        //[HttpGet, HttpPost]
        //[Route("/adfs/oauth2/postlogout")]
        //public async Task<IActionResult> AdfsPostLogout()
        //{
        //    int clientId = 1;
        //    var clientInfo = _clientDetails.Where(x => x.IsActive && x.IdpClientId == clientId).First();
        //    return Redirect(clientInfo.LoginUrl);
        //}

        #endregion

        #region Form Based Login

        /// <summary>
        /// this will execute from OnePortal Login, form based login
        /// </summary>
        /// <param name="user"></param>
        /// <returns></returns>
        [HttpPost]
        [Route("oauth2/token")]
        public async Task<ObjectResult> Post([FromBody] UserLoginModel user)
        {
            if (ModelState.IsValid)
            {
                IdpUserDTO userInfo = await _userInfo.GetUserDetailsByCredentials(user.UserId, user.Password);
                if (userInfo != null)
                {
                    if (userInfo.IsLoginEnabled == false)
                    {
                        return BadRequest(new
                        {
                            Item = new { },
                            Message = "Login is deactivated for this account!",
                            StatusCode = StatusCodes.Status400BadRequest
                        });
                    }
                    if (userInfo.IsFirstTimeLogin)
                    {
                        return Ok(new
                        {
                            Item = new
                            {
                                step = "first-time-login",
                                emailId = userInfo.EmailId,
                                mobileNumber = userInfo.MobileNumber,
                                firstName = userInfo.FirstName,
                                token = userInfo.MobileVerificationToken
                            },
                            Message = $"Hi, {userInfo.FirstName}, Please verify your mobile number and change default password before continue.",
                            StatusCode = StatusCodes.Status200OK
                        });
                    }

                    string requestFromType = _commonConfigurations.RequestFromType;
                    if (requestFromType == "mobile")
                    {
                        (JwtToken, bool, string, IdpClient) response = await HandleIdpForMobileLogin(userInfo.UserTypeInfo.Code, userInfo.EmailId, new()
                        {
                            AccessToken = "-",
                            Scope = "-",
                            TokenType = "mobile-form-based",
                            RefreshToken = string.Empty,
                            IdToken = string.Empty,
                            ExpiresIn = 0
                        });
                        if (response.Item2)
                        {
                            return Ok(new
                            {
                                StatusCode = StatusCodes.Status200OK,
                                Item = new
                                {
                                    Identity = response.Item1,
                                    UserInfo = userInfo,
                                    SessionCode = response.Item3,
                                    ClientInfo = new
                                    {
                                        Id = response.Item4.IdpClientId,
                                        Secret = response.Item4.ClientSecret,
                                    }
                                },
                                Message = "You are authorized to access the system.",
                            });
                        }
                        return BadRequest(new
                        {
                            Item = new { },
                            Message = "Please enter correct user name & password!",
                            StatusCode = StatusCodes.Status400BadRequest
                        });
                    }

                    string userTypeCode = userInfo.UserTypeInfo.Code.ToLower();
                    IdpClient clientInfo = GetClientInfoByUserTypeCode(userTypeCode);
                    _cookieService.SetIdpCookie(Constants.IDP_INIT_CLIENT_ID, clientInfo.IdpClientId.ToString());
                    string redirectUrl = await HandleIdpLoginUrlAsync(new OpenAMUserInfo
                    {
                        Email = userInfo.EmailId
                    }, new OpenAMToken
                    {
                        AccessToken = "-",
                        Scope = "-",
                        TokenType = "form-based",
                        RefreshToken = string.Empty,
                        IdToken = string.Empty,
                        ExpiresIn = 0
                    }, clientInfo);
                    return Ok(new
                    {
                        Item = new
                        {
                            emailId = userInfo.EmailId,
                            redirectUrl,
                        },
                        Message = "You are authorized to access the system.",
                        StatusCode = StatusCodes.Status200OK
                    });
                }
                else
                {
                    return BadRequest(new
                    {
                        Item = new { },
                        Message = "Please enter correct user name & password!",
                        StatusCode = StatusCodes.Status400BadRequest
                    });
                }
            }
            return BadRequest(ModelState);
        }
        #endregion

        #region User Access and Logout

        /// <summary>
        /// this method will verify the user's provided token and validate
        /// and IDP will redirect to respective application
        /// </summary>
        /// <param name="tokenInput"></param>
        /// <returns></returns>
        [HttpPost]
        [Route("/oauth2/access_token")]
        public async Task<IActionResult> AccessToken(TokenInputModel tokenInput)
        {
            string response_message = "";
            if (tokenInput.ClientId <= 0 || string.IsNullOrEmpty(tokenInput.ClientSecret) || string.IsNullOrWhiteSpace(tokenInput.ClientSecret) || string.IsNullOrEmpty(tokenInput.Code) || string.IsNullOrWhiteSpace(tokenInput.Code))
            {
                response_message = "ClientId or Client Secret or Auth Code is null or empty.";
                return Ok(new
                {
                    StatusCode = StatusCodes.Status400BadRequest,
                    Item = new
                    {
                        message = response_message
                    }
                });
            }

            bool isValidClientCreds = await _authServices.IsValidClientCredential(tokenInput.ClientId, tokenInput.ClientSecret);

            if (isValidClientCreds)
            {
                (JwtToken, bool, IdpUserDTO) tokenDetails = await _sessionInfoServices.CheckCodeAndFetchAssignedToken(tokenInput.Code, tokenInput.ClientId);
                JwtToken token = tokenDetails.Item1;
                bool codeInvalidOrExpired = tokenDetails.Item2;
                IdpUserDTO userDetails = tokenDetails.Item3;
                if (!codeInvalidOrExpired)
                {
                    if (token != null)
                    {
                        return Ok(new
                        {
                            StatusCode = StatusCodes.Status200OK,
                            Item = new
                            {
                                Identity = token,
                                UserInfo = userDetails
                            }
                        });
                    }
                    else
                    {
                        response_message = "Jwt Token is null. Access to this page is restricted";
                    }
                }
                else
                {
                    response_message = "Auth Code is invalid or expired. Access to this page is restricted";
                }
            }
            else
            {
                response_message = "ClientId or Client Secret is invalid. Access to this page is restricted";
            }

            return Ok(new
            {
                StatusCode = StatusCodes.Status400BadRequest,
                Item = new
                {
                    message = response_message
                }
            });
        }



        /// <summary>
        /// use this action to authorize user to access other clients
        /// </summary>
        /// <param name="appId"></param>
        /// <param name="client_id"></param>
        /// <param name="clientSecret"></param>
        /// <returns></returns>
        [HttpGet]
        [Route("/user/oauth2/authorize")]
        public async Task<IActionResult> Authorize(Guid appId, int client_id, string clientSecret)
        {
            List<IdpClient> _clientDetails = await IdpClientDetails();
            IdpClient onePortalConfig = _clientDetails.FirstOrDefault(c => c.ClientName == OnePortalName);
            if (client_id <= 0 || string.IsNullOrEmpty(clientSecret) || string.IsNullOrWhiteSpace(clientSecret))
            {
                return RedirectPermanent(onePortalConfig.LoginUrl);
            }
            bool isValidClientCreds = await _authServices.IsValidClientCredential(onePortalConfig.IdpClientId, onePortalConfig.ClientSecret);
            if (isValidClientCreds)
            {
                IdpClient requestedClientInfo = _clientDetails.FirstOrDefault(x => x.IsActive && x.IdpClientId == client_id);
                if (requestedClientInfo != null)
                {
                    string authCode_redirect_uri = requestedClientInfo.RedirectAuthCodeUri;
                    string idp_session_info = _cookieService.GetIdpCookie(Constants.IDP_SESSION_INFO);
                    IdpSessionInfo latestSessionInfo = await _sessionInfoServices.GetLatestSessionBySessionId(idp_session_info);
                    if (latestSessionInfo != null)
                    {
                        IdpSessionInfo sessionForClient = await _sessionInfoServices.GetSessionBySessionIdAndClientId(idp_session_info, client_id);
                        string code = string.Empty;
                        string emailId = string.Empty;
                        if (sessionForClient == null)
                        {
                            IdpSessionInfo newSession = await _sessionInfoServices.CloneSessionForNewClient(latestSessionInfo, client_id);
                            if (newSession != null)
                            {
                                code = await _authServices.GenerateTokenLogEntryForLogin(newSession);
                                authCode_redirect_uri = $"{authCode_redirect_uri}?code={code}&emailId={newSession.EmailId}";
                                emailId = newSession.EmailId;
                            }
                            else
                            {
                                authCode_redirect_uri = requestedClientInfo.LoginUrl;
                            }
                        }
                        else
                        {
                            code = await _authServices.GenerateTokenLogEntryForLogin(sessionForClient);
                            authCode_redirect_uri = $"{authCode_redirect_uri}?code={code}&emailId={sessionForClient.EmailId}";
                            emailId = sessionForClient.EmailId;
                        }

                        if (emailId.Length > 0)
                        {
                            if (requestedClientInfo.ClientName == LMSPortalCode)
                            {
                                string lms_response_loginurl = await _lmsAuthService.LoginWithEmailId(emailId);
                                if (lms_response_loginurl.Length > 0)
                                {
                                    authCode_redirect_uri = lms_response_loginurl;
                                    return RedirectPermanent(authCode_redirect_uri);
                                }
                                return RedirectPermanent(requestedClientInfo.LogoutUrl);
                            }
                            IdpUserDTO userInfoByEmail = await _userInfo.GetUserDetailsByEmail(emailId, client_id, requestedClientInfo.ClientName);
                            bool isFinanceApp = (requestedClientInfo.ClientName ?? "").ToLower() == "finance-portal-admin";
                            if (!isFinanceApp && !ValidateClientIdAndUserTypeCode(userInfoByEmail.UserTypeInfo.Code, client_id, requestedClientInfo.ClientName))
                            {
                                Response.Cookies.Delete("idp_session_info");
                                authCode_redirect_uri = onePortalConfig.LoginUrl;
                            }
                        }
                    }
                    else
                    {
                        Response.Cookies.Delete("idp_session_info");
                        authCode_redirect_uri = onePortalConfig.LogoutUrl;
                    }
                    return RedirectPermanent(authCode_redirect_uri);
                }
            }
            return RedirectPermanent(onePortalConfig.LoginUrl);
        }



        /// <summary>
        /// use this action once user click on logout.
        /// </summary>
        /// <param name="client_id"></param>
        /// <param name="clientSecret"></param>
        /// <returns></returns>
        /// <exception cref="UserUnauthorizedCustomException"></exception>
        [HttpGet]
        [Route("/user/oauth2/logout")]
        public async Task<IActionResult> UserAfterLogout(int client_id, string clientSecret)
        {
            string requestFromType = _commonConfigurations.RequestFromType;
            List<IdpClient> _clientDetails = await IdpClientDetails();
            IdpClient onePortalConfig = _clientDetails.FirstOrDefault(c => c.ClientName == OnePortalName);
            bool formBasedLogin = _config.GetValue<bool>("FormBasedLogin");
            string logout_url = onePortalConfig.LoginUrl;
            if (formBasedLogin)
            {
                var _validClientInfo = await _authServices.ValidateClient(client_id, clientSecret);
                if (_validClientInfo)
                {
                    IdpClient client = _clientDetails.Where(x => x.IsActive && x.IdpClientId == client_id).FirstOrDefault();
                    if (client != null)
                    {
                        string session_id = _cookieService.GetIdpCookie(Constants.IDP_SESSION_INFO);
                        IdpSessionInfo sessionInfo = await _sessionInfoServices.GetLatestSessionBySessionId(session_id);
                        if (sessionInfo != null)
                        {
                            string logoutCode = await _authServices.GenerateTokenLogEntryForLogout(sessionInfo, client.IdpClientId, client.LogoutUrl);
                            AuthCodeLog authCodeLog = await _sessionInfoServices.CheckCodeAndFetchDataForLogout(logoutCode);
                            if (authCodeLog != null)
                            {
                                bool signOutStatus = await _sessionInfoServices.LogoutSession(client_id, authCodeLog.SessionId, onePortalConfig.IdpClientId);
                                if (signOutStatus && onePortalConfig.IdpClientId == client_id)
                                {
                                    foreach (string key in Request.Cookies.Keys)
                                    {
                                        Response.Cookies.Delete(key);
                                    }
                                }
                                logout_url = authCodeLog.ApplicationLogoutUri;
                            }
                        }
                    }
                }
            }
            if (requestFromType == "mobile")
            {
                return Ok(new
                {
                    StatusCode = StatusCodes.Status200OK,
                    Message = "Logout was successful."
                });
            }
            else
            {
                return RedirectPermanent(logout_url);
            }
        }


        /// <summary>
        /// use this action to access lms account with student unique id.
        /// </summary>
        /// <param name="uniqueId"></param>
        /// <returns></returns>
        [HttpPost]
        [Route("/user/oauth2/access-lms")]
        public async Task<IActionResult> AccessLms(string uniqueId)
        {
            HttpStatusCode statusCode = HttpStatusCode.Unauthorized;
            string authCode_redirect_uri = string.Empty;
            Guid _uniqueId = Guid.Parse(uniqueId);
            string lms_response_loginurl = await _lmsAuthService.LoginWithStudentUniqueId(_uniqueId);
            if (lms_response_loginurl.Length > 0)
            {
                authCode_redirect_uri = lms_response_loginurl;
                statusCode = HttpStatusCode.OK;
            }
            return Ok(new
            {
                redirectUrl = authCode_redirect_uri,
                statusCode
            });
        }

        #endregion


        /// <summary>
        /// validate the refresh token and create a new access token for further usages
        /// </summary>
        /// <param name="refreshToken">
        /// refresh token object which will contains the 
        /// current clientId clientSecret and RefreshToken
        /// </param>
        /// <returns></returns>
        [HttpPost("/user/oauth2/refresh-token")]
        public async Task<ObjectResult> Post(RefreshTokenEntity refreshToken)
        {
            var _clientDetails = await IdpClientDetails();
            IdpClient requestedClientInfo = _clientDetails.FirstOrDefault(x => x.IsActive && x.ClientSecret == refreshToken.ClientSecret && x.IdpClientId == refreshToken.ClientId);
            if (requestedClientInfo != null)
            {
                string idp_session_info = _cookieService.GetIdpCookie(Constants.IDP_SESSION_INFO);
                IdpSessionInfo latestSessionInfo = await _sessionInfoServices.GetLatestSessionBySessionId(idp_session_info);
                if (latestSessionInfo != null)
                {
                    IdpSessionInfo sessionForClient = await _sessionInfoServices.GetSessionBySessionIdAndClientId(idp_session_info, refreshToken.ClientId);
                    if (sessionForClient != null)
                    {
                        if (sessionForClient.RefreshToken == refreshToken.RefreshToken)
                        {
                            IdpSessionInfo newSession = await _sessionInfoServices.CloneSessionForNewClient(sessionForClient, refreshToken.ClientId, true);
                            if (newSession != null)
                            {
                                return Ok(new
                                {
                                    StatusCode = StatusCodes.Status200OK,
                                    Item = new
                                    {
                                        requestInfo = refreshToken,
                                        tokenInfo = new
                                        {
                                            emailId = newSession.EmailId,
                                            accessToken = newSession.AccessToken,
                                            expiresAt = newSession.ExpiresAt.Second,
                                            refreshToken = newSession.RefreshToken,
                                        }
                                    },
                                    Message = "refresh token generated successfully.",
                                });
                            }
                        }
                    }
                }
            }

            return Ok(new
            {
                StatusCode = StatusCodes.Status401Unauthorized,
                Item = new
                {
                    refreshToken
                },
                Message = "failed to generate the refresh token.",
            });
        }


        /// <summary>
        /// this api will return the entire appsettings file once the application is hosted.
        /// apiKey : provide a valid api key
        /// environmentName : require the current environment name, with prefix (.), 
        /// for example if environment is Development then value should be .Development
        /// </summary>
        /// <param name="apiKey">provide a valid api key</param>
        /// <param name="environmentName">require the current environment name, with prefix (.), 
        /// for example if environment is Development then value should be .Development</param>
        /// <returns></returns>
        [HttpGet("read-app-config")]
        public ObjectResult ReadConfigFile(string apiKey, string? environmentName)
        {
            if (apiKey == "3E814f7fPi0/azSN2IDcGQ==")
            {
                string rootPath = _environment.ContentRootPath;
                environmentName ??= "";
                //combine the root path with that of our json file inside root directory
                var fullPath = Path.Combine(rootPath, $"appsettings{environmentName}.json");
                var jsonData = System.IO.File.ReadAllText(fullPath);
                var configItems = System.Text.Json.JsonSerializer.Deserialize<object>(jsonData);
                return Ok(new
                {
                    requestInfo = "get all application configuration after deployment",
                    appConfigurations = configItems,
                    dateTime = DateTime.Now,
                });
            }
            return BadRequest(new
            {
                statusCode = HttpStatusCode.BadRequest,
                message = "Your request could not be understood by the server due to malformed syntax.",
                errorId = Guid.NewGuid().ToString()
            });
        }

        #region Azure AD Related Configurations 
        //[HttpGet]
        //[Route("/oauth2/authorize")]
        //public async Task<IActionResult> Authorize(int client_id, string clientSecret)
        //{
        //    if (!_authServices.ValidateClient(client_id, clientSecret).Result)
        //        throw new UserUnauthorizedCustomException("ClientId or Client Secret is null or empty.");

        //    var authCode_redirect_uri = _clientDetails.Where(x => x.IsActive && x.IdpClientId == client_id).Select(x => x.RedirectAuthCodeUri).FirstOrDefault();

        //    if (string.IsNullOrEmpty(authCode_redirect_uri))
        //        throw new UserUnauthorizedCustomException("Client redirect uri is null or empty.");

        //    string idp_session_info = _cookieService.GetIdpCookie(Constants.IDP_SESSION_INFO);

        //    //// Session cookie is not present (expired, logged out, incognito, new browser/device)
        //    if (string.IsNullOrWhiteSpace(idp_session_info))
        //    {
        //        //Client details mentioned, going for Open AM authentication             
        //        _logger.LogInformation($"---do Open AM SignIn");

        //        _cookieService.SetIdpCookie(Constants.IDP_INIT_CLIENT_ID, client_id.ToString());
        //        //adfs url will configure here
        //        string openAMLoginUrl = await _openAMService.GetOpenAMLoginUrl();
        //        _logger.LogInformation($"**** openAMLoginUrl ***** {openAMLoginUrl}");
        //        return Redirect(openAMLoginUrl);
        //    }
        //    //// Session cookie is present (already logged in with same/diff client)
        //    else
        //    {
        //        var latestSessionInfo = await _sessionInfoServices.GetLatestSessionBySessionId(idp_session_info);
        //        if (latestSessionInfo != null)
        //        {
        //            _logger.LogInformation($"No need to Sign-In separately as current session persists (so does Idp Session Cookie)");
        //            // In case no source was specified, redirect to default client's app-component page (from there auth flow will re-initiate)
        //            var sessionForClient = await _sessionInfoServices.GetSessionBySessionIdAndClientId(idp_session_info, client_id);

        //            var code = string.Empty;
        //            if (sessionForClient == null)
        //            {
        //                var newSession = await _sessionInfoServices.CloneSessionForNewClient(latestSessionInfo, client_id);
        //                code = await _authServices.GenerateTokenLogEntryForLogin(newSession);
        //                authCode_redirect_uri = $"{authCode_redirect_uri}?code={code}&emailId={newSession.EmailId}";
        //            }
        //            else
        //            {
        //                code = await _authServices.GenerateTokenLogEntryForLogin(sessionForClient);
        //                authCode_redirect_uri = $"{authCode_redirect_uri}?code={code}&emailId={sessionForClient.EmailId}";
        //            }
        //        }
        //        // In case session info is invalid/ expired delete the cookie and re-start the flow with same params
        //        else
        //        {
        //            Response.Cookies.Delete("idp_session_info");
        //            authCode_redirect_uri = $"/oauth2/authorize?client_id={client_id}&clientSecret={clientSecret}";
        //        }
        //        return Redirect(authCode_redirect_uri);
        //    }

        //}

        //[HttpGet]
        //[Route("/oauth2/authcode")]
        //public async Task<IActionResult> GetOpenAMAuthCode(string code, string state)
        //{
        //    if (string.IsNullOrEmpty(_cookieService.GetIdpCookie(Constants.IDP_INIT_CLIENT_ID)))
        //        throw new UserUnauthorizedCustomException("clientId cookie is null or empty.");

        //    int idpClientId = int.Parse(_cookieService.GetIdpCookie(Constants.IDP_INIT_CLIENT_ID));
        //    var client = _clientDetails.Where(x => x.IsActive && x.IdpClientId == idpClientId).FirstOrDefault();
        //    if (client == null)
        //        throw new UserUnauthorizedCustomException("client doesn't exist.");

        //    if (string.IsNullOrEmpty(code))
        //    {
        //        Response.Cookies.Delete("idp_session_info");
        //        Redirect($"/oauth2/authorize?client_id={idpClientId}&clientSecret={client.ClientSecret}");
        //    }

        //    OpenAMToken openAMToken = await _openAMService.GetOpenAMTokenInfo(code);
        //    if (openAMToken != null)
        //    {
        //        // Get UserInfo from AuthToken
        //        OpenAMUserInfo openAMUser = await _openAMService.GetOpenAMUserInfo(openAMToken.AccessToken);

        //        if (openAMUser != null)
        //        {
        //            return await HandleIdpLoginAsync(openAMUser, openAMToken, client);
        //        }
        //        else
        //            throw new UserUnauthorizedCustomException("Unable to get User Information", false, client.ErrorPageUrl);
        //    }
        //    else
        //        throw new UserUnauthorizedCustomException("Unable to get AccessToken", false, client.ErrorPageUrl);
        //}

        //[HttpPost]
        //[Route("/oauth2/refresh_token")]
        //public async Task<IActionResult> RefreshToken(JwtToken token)
        //{
        //    string sessionId = _cookieService.GetIdpCookie(Constants.IDP_SESSION_INFO);
        //    if (string.IsNullOrEmpty(sessionId))
        //        throw new UserUnauthorizedCustomException("Session is invalid or expired.", true);

        //    var newtoken = await _sessionInfoServices.RefreshToken(token, sessionId);
        //    if (newtoken != null)
        //    {
        //        return Ok(newtoken);
        //    }
        //    else
        //        throw new UserUnauthorizedCustomException("Unable to get AccessToken", true);
        //}

        //[HttpGet]
        //[Route("/oauth2/endSession")]
        //public async Task<IActionResult> Logout(int client_id, string clientSecret, string logoutRedirectUri)
        //{
        //    if (!_authServices.ValidateClient(client_id, clientSecret).Result || string.IsNullOrEmpty(logoutRedirectUri))
        //        throw new UserUnauthorizedCustomException("ClientId or Client Secret or logoutRedirectUri is null or empty.");

        //    var client = _clientDetails.Where(x => x.IsActive && x.IdpClientId == client_id).FirstOrDefault();

        //    string session_id = _cookieService.GetIdpCookie(Constants.IDP_SESSION_INFO);
        //    IdpSessionInfo sessionInfo = await _sessionInfoServices.GetLatestSessionBySessionId(session_id);
        //    if (sessionInfo == null)
        //        throw new UserUnauthorizedCustomException("session has expired.", false, client.ErrorPageUrl);
        //    else
        //    {
        //        var endSessionUrl = _config["AuthSetting:end_session_url"];
        //        var postLogoutUrl = _config["AuthSetting:post_logout_url"];//client_logout_uri
        //        var tenant = _config["AuthSetting:tenant"];
        //        var sec_code = await _authServices.GenerateTokenLogEntryForLogout(sessionInfo, logoutRedirectUri);
        //        string openAMLogoutUri = $"{endSessionUrl}/{tenant}/oauth2/v2.0/logout?post_logout_redirect_uri={postLogoutUrl}?logoutCode={sec_code}&redirectUri={logoutRedirectUri}";
        //        return Redirect(openAMLogoutUri);
        //    }
        //} 
        //[HttpGet]
        //[Route("/oauth2/after_logout")]
        //public async Task<IActionResult> AfterADLogout(string logoutCode)
        //{
        //    AuthCodeLog authCodeLog = await _sessionInfoServices.CheckCodeAndFetchDataForLogout(logoutCode);
        //    if (authCodeLog == null)
        //        throw new UserUnauthorizedCustomException("logoutCode is invalid");

        //    var signOutStatus = await _sessionInfoServices.LogoutSession(authCodeLog.SessionId);

        //    if (signOutStatus)
        //    {
        //        //await HttpContext.SignOutAsync(CookieAuthenticationDefaults.AuthenticationScheme);

        //        foreach (var key in Request.Cookies.Keys)
        //        {
        //            Response.Cookies.Delete(key);
        //        }
        //    }
        //    else
        //        throw new UserUnauthorizedCustomException("user failed to signout", false);

        //    return Redirect(authCodeLog.ApplicationLogoutUri);
        //}
        #endregion

        #region private methods to handle user presents
        private async Task<List<IdpClient>> IdpClientDetails()
        {
            List<IdpClient> _response = await _authServices.GetIdpClientDetails();
            return _response;
        }
        //private async Task<IActionResult> HandleIdpLoginAsync(OpenAMUserInfo openAMUser, OpenAMToken openAMToken, IdpClient client)
        //{
        //    IdpUserDTO idpUser = await _authServices.GetIdpUserInformation(openAMUser, client.IdpClientId);
        //    string redirect_uri = client.RedirectAuthCodeUri;
        //    if (idpUser != null)
        //    {
        //        long openAMSessionId = await _sessionInfoServices.AddOpenAMSessionInfo(idpUser.EmailId, openAMToken);
        //        IdpSessionInfo sessionInfo = await _sessionInfoServices.CreateSession(openAMSessionId, client.IdpClientId, idpUser.EmailId);
        //        foreach (string key in Request.Cookies.Keys)
        //        {
        //            Response.Cookies.Delete(key);
        //        }
        //        _cookieService.SetIdpCookie(Constants.IDP_SESSION_INFO, sessionInfo.SessionId.ToString());
        //        string sec_code = await _authServices.GenerateTokenLogEntryForLogin(sessionInfo);
        //        redirect_uri = $"{redirect_uri}?code={sec_code}&emailId={idpUser.EmailId}&name={idpUser.FirstName}";
        //    }
        //    else
        //    {
        //        throw new UserUnauthorizedCustomException("User doesnot exist.");
        //    }

        //    return Redirect(redirect_uri);
        //}
        private async Task<string> HandleIdpLoginUrlAsync(OpenAMUserInfo openAMUser, OpenAMToken openAMToken, IdpClient client)
        {
            IdpUserDTO idpUser = await _authServices.GetIdpUserInformation(openAMUser, client.IdpClientId);
            string redirect_uri = client.RedirectAuthCodeUri;
            if (idpUser != null)
            {
                long openAMSessionId = await _sessionInfoServices.AddOpenAMSessionInfo(idpUser.EmailId, openAMToken);
                IdpSessionInfo sessionInfo = await _sessionInfoServices.CreateSession(openAMSessionId, client.IdpClientId, idpUser.EmailId);
                foreach (string key in Request.Cookies.Keys)
                {
                    Response.Cookies.Delete(key);
                }
                _cookieService.SetIdpCookie(Constants.IDP_SESSION_INFO, sessionInfo.SessionId.ToString());
                string sec_code = await _authServices.GenerateTokenLogEntryForLogin(sessionInfo);
                redirect_uri = $"{redirect_uri}?code={sec_code}&emailId={idpUser.EmailId}&name={idpUser.FirstName}";
            }
            return redirect_uri;
        }


        private async Task<(JwtToken, bool, string, IdpClient)> HandleIdpForMobileLogin(string userTypeCode, string emailId, OpenAMToken openAMToken)
        {
            var clientInfo = GetClientInfoByUserTypeCode(userTypeCode);
            long openAMSessionId = await _sessionInfoServices.AddOpenAMSessionInfo(emailId, openAMToken);
            IdpSessionInfo sessionInfo = await _sessionInfoServices.CreateSession(openAMSessionId, clientInfo.IdpClientId, emailId);
            foreach (string key in Request.Cookies.Keys)
            {
                Response.Cookies.Delete(key);
            }
            _cookieService.SetIdpCookie(Constants.IDP_SESSION_INFO, sessionInfo.SessionId.ToString());
            string sec_code = await _authServices.GenerateTokenLogEntryForLogin(sessionInfo);

            JwtToken token = new JwtToken
            {
                AccessToken = sessionInfo.AccessToken,
                Scope = "openid",
                TokenType = "Bearer",
                ExpiresIn = sessionInfo.ExpiresAt.Second,
                RefreshToken = sessionInfo.RefreshToken
            };
            return (token, true, sec_code, clientInfo);
        }


        private IdpClient GetClientInfoByUserTypeCode(string userTypeCode)
        {
            string _clientSecret = _commonConfigurations.ReadKeyFromHeader("X-Appsecret") ?? "";
            List<IdpClient> _clientDetails = IdpClientDetails().Result;
            int clientId = 2;
            switch (userTypeCode.ToLower())
            {
                case "ts":
                case "stf":
                    {
                        clientId = (int)IdpClientEnum.STAFFPORTAL;
                        bool isOnePortalDashboardConfigured = _config.GetValue<bool>("IsOnePortalDashboardConfigured");
                        if (isOnePortalDashboardConfigured)
                        {
                            clientId = (int)IdpClientEnum.SLCMPORTAL;
                        }
                    }
                    break;
                case "st":
                case "gd":
                case "al": { clientId = (int)IdpClientEnum.STUDENTPORTAL; } break;
                case "aplnct": { clientId = (int)IdpClientEnum.APPLICANT; } break;
                default:
                    break;
            }

            if (_clientSecret.Length > 0)
            {
                var _clientInfo = _clientDetails.FirstOrDefault(c => c.ClientSecret == _clientSecret);
                if (_clientInfo != null)
                {
                    clientId = _clientInfo.IdpClientId;
                }
            }
            IdpClient clientInfo = _clientDetails.Where(x => x.IsActive && x.IdpClientId == clientId).FirstOrDefault();
            return clientInfo;
        }
        private bool ValidateClientIdAndUserTypeCode(string userTypeCode, int clientId, string clientName)
        {
            switch (userTypeCode.ToLower())
            {
                case "ts":
                case "stf":
                    {
                        return StaffPortals.Contains(clientName);
                    }
                case "st":
                case "gd":
                case "aplnct":
                case "al":
                    {
                        return StudentPortals.Contains(clientName);
                    }
                default:
                    break;
            }
            return false;
        }
        #endregion
    }
}
