﻿using IEMS.Core.ApplicationCommonConfigurations.Interfaces;
using IEMS.Core.UserClaimsHandler.Interfaces;
using IEMS_IDP.Entity.Account;
using IEMS_IDP.Services.Interface.FirstTimeLogin;
using IEMS_IDP.Services.Interface.ForgotPassword;
using Microsoft.AspNetCore.Mvc;

namespace IEMS_IDP.Controllers.UserCredentialManager
{
    /// <summary>
    /// user password change manager
    /// </summary>
    [Route("api/account/security")]
    [ApiController]
    public class UserCredentialManagerController : ControllerBase
    {
        private readonly IForgotPasswordRepository _forgotPasswordService;
        private readonly IUserClaimsHandler _userIdentity;
        private readonly IApplicationCommonConfigurations _applicationCommonConfigurations;
        private readonly IFirstTimeLoginService _firstTimeLoginService;
        private readonly IConfiguration _config;


        /// <summary>
        /// user password change manager constructor
        /// </summary>
        /// <param name="forgotPasswordService">forgot password service</param>
        /// <param name="userIdentity">user Identity service to get loggedin user details</param>
        /// <param name="applicationCommonConfigurations">application common configurations</param>
        public UserCredentialManagerController(IConfiguration config,
            IForgotPasswordRepository forgotPasswordService,
            IUserClaimsHandler userIdentity,
            IApplicationCommonConfigurations applicationCommonConfigurations,
            IFirstTimeLoginService firstTimeLoginService)
        {
            _config = config;
            _forgotPasswordService = forgotPasswordService;
            _userIdentity = userIdentity;
            _applicationCommonConfigurations = applicationCommonConfigurations;
            _firstTimeLoginService = firstTimeLoginService;
        }


        /// <summary>
        /// use this api to reqeust for password change
        /// </summary>
        /// <returns></returns>
        [HttpPost("change-password/request")]
        public async Task<ObjectResult> Post([FromBody] ForgotPasswordViewModel forgotPasswordModel)
        {
            if (ModelState.IsValid)
            {
                string applicationName = _applicationCommonConfigurations.RequestedFromApplication.ToLower();
                string otp = _applicationCommonConfigurations.GenerateAutoId(false, 6);

                ForgotPasswordResponseModel response = await _forgotPasswordService.RequestToChangePassword(applicationName, otp, forgotPasswordModel);
                return Ok(response);
            }
            return BadRequest(ModelState);
        }


        /// <summary>
        /// use this api to resend OTP
        /// </summary>
        /// <param name="referenceId"></param>
        /// <returns></returns>
        [HttpPost("change-password/resend-otp/{referenceId}")]
        [NonAction]
        public async Task<ObjectResult> Post([FromQuery] Guid referenceId)
        {
            string applicationName = _applicationCommonConfigurations.RequestedFromApplication.ToLower();
            string otp = _applicationCommonConfigurations.GenerateAutoId(false, 6);
            ForgotPasswordResponseModel response = await _forgotPasswordService.ResendOTPToChangePassword(applicationName, otp, new()
            {
                ReferenceId = referenceId
            });
            return Ok(response);
        }

        /// <summary>
        /// use this api to reset the password
        /// </summary>
        /// <returns></returns>
        [HttpPut("password/reset")]
        public async Task<ObjectResult> Put([FromBody] ResetPasswordViewModel resetPasswordViewModel)
        {
            if (ModelState.IsValid)
            {
                string applicationName = _applicationCommonConfigurations.RequestedFromApplication.ToLower();
                ResetPasswordResponseModel response = await _forgotPasswordService.ResetPassword(applicationName, resetPasswordViewModel);
                return Ok(response);
            }
            return BadRequest(ModelState);
        }


        /// <summary>
        /// use this api to change password after login
        /// </summary>
        /// <returns></returns>
        [HttpPost("user/request/change-password")]
        public async Task<ObjectResult> Post()
        {
            if (_userIdentity.UserIdentity != null)
            {
                string applicationName = _applicationCommonConfigurations.RequestedFromApplication.ToLower();
                string otp = _applicationCommonConfigurations.GenerateAutoId(false, 6);
                ForgotPasswordResponseModel response = await _forgotPasswordService.RequestToChangePassword(applicationName, otp, new ForgotPasswordViewModel
                {
                    UserLogonName = _userIdentity.UserIdentity.EmailId
                });
                return Ok(response);
            }
            return Unauthorized("Please login to continue!");
        }


        /// <summary>
        /// resend OTP for first time login
        /// </summary>
        /// <param name="token">token</param>
        /// <returns></returns>
        [HttpPost("user/first-time-login/resend-otp")]
        public async Task<ObjectResult> Post(string token)
        {
            string responseToken = await _firstTimeLoginService.ResendVerificationOTP(token);
            bool status = (responseToken ?? "").Length > 0;
            return Ok(new
            {
                Item = new
                {
                    status,
                    token = responseToken,
                },
                Message = status ? $"Please verify your mobile number before continue." : "Request is not valid please try again later.",
                StatusCode = StatusCodes.Status200OK
            });
        }


        /// <summary>
        /// verify token and change password based on token generated.
        /// </summary>
        /// <param name="uniqueId"></param>
        /// <param name="model"></param>
        /// <returns></returns>
        [HttpPost("user/first-time-login/verify")]
        public async Task<ObjectResult> Post(string uniqueId, UserFirstTimeLoginModel model)
        {
            bool response = await _firstTimeLoginService.VerifyOTPAndChangePassword(model);
            return Ok(new
            {
                Item = new
                {
                    status = response,
                    uniqueId,
                },
                Message = $"Please login to continue!",
                StatusCode = response ? StatusCodes.Status200OK : StatusCodes.Status400BadRequest
            });
        }
    }
}
