﻿using IEMS.Core.Academics.Database.DatabaseEntities;
using IEMS.Identity.Connect.OAuth2.Configurations._Endpoints;
using IEMS.Identity.Connect.OAuth2.Configurations._OauthRequest;
using IEMS.Identity.Connect.OAuth2.Configurations._Services;
using IEMS_IDP.Services.Implementation;
using IEMS_IDP.Services.Interface;
using IEMS_IDP.Utility;
using Microsoft.AspNetCore.Mvc;
using Microsoft.IdentityModel.Tokens;
using System.Web;

namespace IEMS_IDP.Controllers
{

    /// <summary>
    ///  OAuth 2.0 Server and OpenId Connect Provider
    /// ref : https://dev.to/mohammedahmed/build-your-own-oauth-20-server-and-openid-connect-provider-in-aspnet-core-60-1g1m
    /// https://github.com/Shoogn/OAuth20Server/tree/master
    /// 
    /// MFA : https://learn.microsoft.com/en-us/aspnet/core/security/authentication/mfa?view=aspnetcore-6.0
    /// QR : https://learn.microsoft.com/en-us/aspnet/core/security/authentication/identity-enable-qrcodes?view=aspnetcore-6.0
    /// </summary>
    public class OAuthController : Controller
    {
        private readonly string tokenIssuer = string.Empty;
        private readonly string authorization_endpoint = string.Empty;
        private readonly string appBaseUrl = string.Empty;
        private readonly string audience = string.Empty;
        private readonly string oneportal_url = string.Empty;
        private readonly string routePrefix = string.Empty;
        private readonly IHttpContextAccessor _httpContextAccessor;
        private readonly IAuthorizeResultService _authorizeResultService;
        private readonly ICodeStoreService _codeStoreService;
        private readonly ILogger<OAuthController> _logger;
        private readonly ICookieService _cookieService;
        private readonly ISessionInfoServices _sessionInfoServices;
        private readonly IUserInfoData _userInfo;

        /// <summary>
        ///  OAuth 2.0 Server and OpenId Connect Provider
        /// </summary>
        /// <param name="logger"></param>
        /// <param name="httpContextAccessor"></param>
        /// <param name="authorizeResultService"></param>
        /// <param name="codeStoreService"></param>
        /// <param name="cookieService"></param>
        /// <param name="sessionInfoServices"></param> 
        /// <param name="userInfo"></param>
        /// <param name="config"></param>
        public OAuthController(ILogger<OAuthController> logger, IHttpContextAccessor httpContextAccessor,
           IAuthorizeResultService authorizeResultService,
           ICodeStoreService codeStoreService,
           ICookieService cookieService,
           ISessionInfoServices sessionInfoServices,
           IUserInfoData userInfo,
           IConfiguration config)
        {
            _logger = logger;
            _httpContextAccessor = httpContextAccessor;
            _authorizeResultService = authorizeResultService;
            _codeStoreService = codeStoreService;
            _cookieService = cookieService;
            _sessionInfoServices = sessionInfoServices;
            _userInfo = userInfo;
            tokenIssuer = config["tokenSettings:issuer"];
            appBaseUrl = config["tokenSettings:appBaseUrl"];
            audience = config["tokenSettings:audience"];
            oneportal_url = config["AppSettings:OnePortalBaseUrl"] + $"/app/auth/login";
            routePrefix = config["AppSettings:RoutePrefix"];
            authorization_endpoint = $"{appBaseUrl}{routePrefix}/oauth/authorize";
        }


        /// <summary>
        /// Authorize a client from here and crate the token for next step.
        /// </summary>
        /// <param name="authorizationRequest"></param>
        /// <returns></returns>
        [HttpGet]
        public async Task<IActionResult> Authorize(AuthorizationRequest authorizationRequest)
        {
            string idp_session_info = _cookieService.GetIdpCookie(Constants.IDP_SESSION_INFO);
            if (!idp_session_info.IsNullOrEmpty())
            {
                IdpSessionInfo latestSessionInfo = await _sessionInfoServices.GetLatestSessionBySessionId(idp_session_info);
                if (latestSessionInfo != null)
                {
                    string emailId = latestSessionInfo.EmailId;
                    var idpUserInfo = await _userInfo.GetUserDetailsByEmail(emailId, -1, authorizationRequest.client_id);
                    var result = _authorizeResultService.AuthorizeRequest(_httpContextAccessor, authorizationRequest);
                    if (!result.HasError)
                    {
                        var openIdLoginModel = new OpenIdConnectLoginRequest
                        {
                            RedirectUri = result.RedirectUri,
                            Code = result.Code,
                            RequestedScopes = result.RequestedScopes,
                            Nonce = result.Nonce
                        };

                        var client_result = _codeStoreService.UpdatedClientDataByCode(openIdLoginModel.Code,
                            openIdLoginModel.RequestedScopes, idpUserInfo, authorizationRequest.client_id, openIdLoginModel.Nonce);
                        if (client_result != null)
                        {
                            openIdLoginModel.RedirectUri = openIdLoginModel.RedirectUri + "&code=" + openIdLoginModel.Code;
                            return Redirect(openIdLoginModel.RedirectUri);
                        }
                    }
                }
            }
            string queryString = "?returnUrl=" + ConvertObjectToQueryString(authorizationRequest);
            return RedirectPermanent(oneportal_url + queryString);
        }


        /// <summary>
        /// 
        /// </summary>
        /// <returns></returns>
        public IActionResult Token()
        {
            var result = _authorizeResultService.GenerateToken(_httpContextAccessor);
            if (result.HasError)
                return RedirectPermanent(oneportal_url);
            return Json(result);
        }


        /// <summary>
        /// 
        /// </summary>
        /// <returns></returns>
        [HttpGet("/.well-known/openid-configuration")]
        public JsonResult GetConfiguration()
        {
            var response = new DiscoveryResponse
            {
                issuer = tokenIssuer,
                authorization_endpoint = authorization_endpoint,
                token_endpoint = $"{appBaseUrl}{routePrefix}/oauth/token",
                token_endpoint_auth_methods_supported = new string[] { "client_secret_basic", "private_key_jwt" },
                token_endpoint_auth_signing_alg_values_supported = new string[] { "RS256", "ES256" },

                acr_values_supported = new string[] { "urn:mace:incommon:iap:silver", "urn:mace:incommon:iap:bronze" },
                response_types_supported = new string[] { "code", "code id_token", "id_token", "token id_token" },
                subject_types_supported = new string[] { "public", "pairwise" },

                userinfo_encryption_enc_values_supported = new string[] { "A128CBC-HS256", "A128GCM" },
                id_token_signing_alg_values_supported = new string[] { "RS256", "ES256", "HS256" },
                id_token_encryption_alg_values_supported = new string[] { "RSA1_5", "A128KW" },
                id_token_encryption_enc_values_supported = new string[] { "A128CBC-HS256", "A128GCM" },
                request_object_signing_alg_values_supported = new string[] { "none", "RS256", "ES256" },
                display_values_supported = new string[] { "page", "popup" },
                claim_types_supported = new string[] { "normal", "distributed" },

                scopes_supported = new string[] { "openid", "profile", "email", "address", "phone", "offline_access" },
                claims_supported = new string[] { "sub", "iss", "auth_time", "acr", "name", "given_name",
                    "family_name", "nickname", "profile", "picture", "website", "email", "email_verified",
                    "locale", "zoneinfo" },
                claims_parameter_supported = true,
                service_documentation = oneportal_url,
                ui_locales_supported = new string[] { "en-US" }
            };
            return Json(response);
        }



        private string ConvertObjectToQueryString(AuthorizationRequest dataToConvert)
        {
            var properties = from p in dataToConvert.GetType().GetProperties()
                             where p.GetValue(dataToConvert, null) != null
                             select p.Name + "=" + HttpUtility.UrlEncode(p.GetValue(dataToConvert, null).ToString());
            string queryString = string.Join("&", properties.ToArray());
            return $"{authorization_endpoint}?" + queryString;
        }
    }
}
